import './App.css';

import ProductsList from './components/ProductsList';
import UserForm from './components/UserForm';
import WelcomeMessage from './components/WelcomeMessage';

function App() {
  return (
   <div className=''>
      <WelcomeMessage/>
<ProductsList/>  
<UserForm/>
   </div>
  );
}

export default App;
