import React from 'react'
import FeatureCard from './FeatureCard'
import ipad from '../images/2020072216355113.jpg';

function ProductsList() {
  return (
    <div className='bg-orange-300 flex gap-4 justify-center item-center'>
         <FeatureCard img={ipad} heading={"ipad"} dec={"ipad 9th gernation"}/>
         <FeatureCard img={ipad} heading={"ipad"} dec={"ipad 8th gernation"}/>
         <FeatureCard img={ipad} heading={"ipad"} dec={"ipad 7th gernation"}/>
    </div>
  )
}

export default ProductsList
