import React, { useState } from 'react'

function UserForm() {
    const [formData, setformData] = useState({
        name: '',
        email: '',
        married: false
    })
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(formData);
    }
    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setformData(previous => ({
            ...previous,
            [name]: type === 'text' ? value : checked
        }))
    }
    return (
        <div className='bg-fuchsia-400'>
            <form onSubmit={handleSubmit} className='flex flex-col justify-center items-center p-4 gap-4'>
                <div>
                    <input type="text" name='name' placeholder='Enter Your Name' value={formData.name} onChange={handleChange} required />
                </div>
                <div>
                    <input type="text" name='email' placeholder='Enter Your Email' value={formData.email} onChange={handleChange} required />
                </div>
                <div>
                    <label htmlFor="married">checked if Married:</label>
                    <input type="checkbox" name='married' checked={formData.married} onChange={handleChange} />
                </div>
                <div>
                    <button className='bg-blue-300 p-2 rounded-xl'>submit</button>
                </div>
            </form>
        </div>
    )
}

export default UserForm
