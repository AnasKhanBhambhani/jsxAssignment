import React from 'react'

function WelcomeMessage() {
    const currentDate = new Date();
    const formatDate  = `${currentDate.toLocaleDateString()} ${currentDate.toLocaleTimeString()}`
  return (
    <div className='bg-slate-300 flex flex-col justify-center items-center'>
<h1 className='font-bold text-2xl'>welcome to my website</h1>
<h2>thank u for visiting</h2>
<h3>current date is {formatDate}</h3>
    </div>
  )
}

export default WelcomeMessage
