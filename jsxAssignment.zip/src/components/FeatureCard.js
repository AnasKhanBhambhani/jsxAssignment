import React from 'react';

function FeatureCard({img,heading,dec}) {
  return (
    <div className='flex flex-col w-52 justify-center items-center gap-4 my-7 shadow-2xl rounded-lg'>
      <img src={img} width='300px' height='300px'/>
      <h1>{heading}</h1>
      <p>{dec}</p>
    </div>
  )
}

export default FeatureCard
